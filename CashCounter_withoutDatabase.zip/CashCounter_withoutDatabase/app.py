# Name: Cash Counter
# Author: Tassadduk Bappi
# Date: 24/09/2022

from flask import render_template, Flask, request
import webbrowser

app = Flask(__name__)


class itemDetails:
    def __init__(self, category, productName, price, salesTax):
        self.category = category
        self.productName = productName
        self.price = price
        self.salesTax = salesTax

itemInCart = []

@app.route('/')
def index():
    print("Hello!")
    data = "Welcome to Cash Counter!"
    
    return render_template('welcome.html', data=data)


@app.route('/login', methods=['POST', 'GET'])
def cashCounter():
    if request.method == 'POST':

        counterUser = request.form.get('counterUser').lower()

        return render_template('mainView.html', counterUser=counterUser)

# Add/Scan items from shopping cart. After calculating corresponding taxes, stores the value in database and displays current items including taxes
@app.route('/addItem', methods=['POST', 'GET'])
def addItem():
    if request.method == 'POST':

        catagory = request.form.get('catagory')
        productName = request.form.get('proName')
        productPrice = request.form.get('proPrice')
        currentUser = request.form.get('currentUser')

        if catagory == 'Imported Food':
            priceWithoutTax = float(productPrice)
            priceTax = priceWithoutTax * 0.05
            includingTax = "{:.2f}".format(priceWithoutTax + priceTax)
        elif catagory == 'Imported Cosmetics':
            priceWithoutTax = float(productPrice)
            priceTax = priceWithoutTax * 0.15
            includingTax = "{:.2f}".format(priceWithoutTax + priceTax)
        elif catagory == 'Cosmetics' or catagory == 'Entertainment':
            priceWithoutTax = float(productPrice)
            priceTax = priceWithoutTax * 0.1
            includingTax = "{:.2f}".format(priceWithoutTax + priceTax)
        else:
            includingTax = productPrice
            priceTax = 0

        newEntry = itemDetails(catagory,productName,includingTax, priceTax)
        itemInCart.append(newEntry)

        return render_template('mainView.html', counterUser=currentUser, itemList=itemInCart)

# get all items under current user and then prints the bill. it also clears the items from the list to start new Add/Scan 
@app.route('/printList', methods=['POST', 'GET'])
def printList():
    if request.method == 'POST':
        print("inside print function!")
        global itemInCart
        itemList = itemInCart
        totallPrice = []
        taxes = []
        
        currentUser = request.form.get('currentUser')

        for item in itemList:
            totallPrice.append(float(item.price))
            taxes.append(float(item.salesTax))

        salesTaxes = "{:.2f}".format(sum(taxes))
        grandTotal = "{:.2f}".format(sum(totallPrice))

        
        itemInCart = []

        return render_template('mainView.html',counterUser=currentUser, Bill=itemList, SalesTaxes=salesTaxes, GrandTotal=grandTotal)

@app.route('/logout', methods=['POST', 'GET'])
def logout():
    if request.method == 'POST':
        print("inside logout function!")
        data = "Welcome to Cash Counter!"
        
        return render_template('welcome.html', data=data)

if __name__=="__main__":

    webbrowser.open('http://127.0.0.1:5000')
    app.run(use_reloader=False, debug=True)
