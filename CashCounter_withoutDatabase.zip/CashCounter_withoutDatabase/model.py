from flask_sqlalchemy import SQLAlchemy
from flask import Flask
from datetime import datetime

app = Flask(__name__)
db = SQLAlchemy(app)

class OnlineUser(db.Model):
    __tablename__='onlineUser'
    ID = db.Column(db.Integer, primary_key=True)
    counterUser = db.Column(db.String(100))

class CashRecord(db.Model):
    __tablename__ = 'cashRecord'
    ID = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.DateTime, default=datetime.now())
    counterUser = db.Column(db.String(100))
    finalBill = db.Column(db.String(50))

class TempInput(db.Model):
    __tablename__='tempInput'
    ID = db.Column(db.Integer, primary_key=True)
    counterUser = db.Column(db.String(100))
    catagory = db.Column(db.String(50))
    productName = db.Column(db.String(100))
    productPrice = db.Column(db.Float)
    taxes = db.Column(db.Float)
    